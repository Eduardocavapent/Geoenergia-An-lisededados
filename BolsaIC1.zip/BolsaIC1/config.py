"""
Configurações e mapeamentos para o pipeline de processamento SINTEF.
"""

ARQUIVO_ENTRADA = "SINTEF datasheet.xlsx"
ARQUIVO_SAIDA = "resultados/SINTEF_Master_Dataset.xlsx"
ABAS_PROCESSAMENTO = ["Data-3mm", "Data-2mm", "Data-2mm-gas"]

# Linha do cabeçalho na planilha original (Excel, 1-indexado)
LINHA_CABECALHO_EXCEL = 11

# Mapeamento: Coluna original (Excel) -> Nome da coluna na tabela Master
MAPEAMENTO_COLUNAS = {
    'C':'Pred_d50_mm', 'D':'Meas_d50_mm', 'E':'IFT_mN_m', 'F':'Nozzle_D_m',
    'G':'Qoil_L_min', 'H':'Qgas_L_min', 'I':'Momentum_Flux_Oil', 'J':'Momentum_Flux_Water',
    'K':'Momentum_Flux_Amp', 'L':'Reduction_Factor_dR', 'M':'Oil_Visc_mPas', 'N':'Gas_Void_Fraction',
    'O':'Gas_Density_kg_m3', 'P':'Oil_Density_Kg_L', 'Q':'Fluid_Density_Kg_m3', 'R':'Mixed_Density_Kg_m3',
    'S':'Volumetric_Velocity_U', 'T':'Modified_Velocity_U_line', 'U':'Gred_m2_s', 'V':'Fr', 'W':'Ue',
    'X':'Re', 'Y':'We', 'Z':'Vi', 'AA':'Modified_We', 'AB':'d50_D_Pred', 'AC':'d50_D_We',
    'AD':'Iter_1', 'AE':'Iter_2', 'AF':'Iter_3', 'AG':'Iter_4', 'AH':'Iter_5',
}

COLUNAS_COM_FORMULA = [
    'C', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
    'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC',
    'AD', 'AE', 'AF', 'AG', 'AH'
]

NOMES_PARAMETROS_EXCEL = [
    "dens_gas", "Qfac", "g", "row", "row__freshwater", "Afac", "Bfac", "z"
]