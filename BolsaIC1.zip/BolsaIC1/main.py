import os
import logging
import pandas as pd
from config import ARQUIVO_ENTRADA, ARQUIVO_SAIDA, ABAS_PROCESSAMENTO, COLUNAS_COM_FORMULA
import pipeline

def main():
    logging.info("=== INICIANDO SISTEMA DE CONVERSÃO SINTEF ===")
    
    # Garante que a pasta de resultados exista
    os.makedirs(os.path.dirname(ARQUIVO_SAIDA), exist_ok=True)
    
    # ---------------------------------------------------------
    # ETAPA 1: Processamento e Estruturação de Dados com Pandas
    # ---------------------------------------------------------
    master_pub, origem = pipeline.processar_etapa_dados(ARQUIVO_ENTRADA, ABAS_PROCESSAMENTO)
    
    # Gravação inicial dos DataFrames (gerando a estrutura base do Excel)
    with pd.ExcelWriter(ARQUIVO_SAIDA, engine="openpyxl") as writer:
        master_pub.to_excel(writer, sheet_name="Master", index=False)
        
        # Configurações de layout profissional (Filtro e congelamento de painéis)
        ws = writer.sheets["Master"]
        ws.auto_filter.ref = ws.dimensions
        ws.freeze_panes = "A2"
        
        # Criação de Tabelas de Resumo Auxiliares
        resumo_nozzle = master_pub.groupby("Nozzle_Type").size().reset_index(name="N_Experimentos")
        resumo_nozzle.to_excel(writer, sheet_name="Resumo_Nozzles", index=False)
        
        resumo_oleos = pd.DataFrame({"Oil_ID": sorted(master_pub["Oil_ID"].dropna().unique())})
        resumo_oleos.to_excel(writer, sheet_name="Resumo_Oleos", index=False)
        
        resumo_tratamentos = pd.DataFrame({"Treatment": sorted(master_pub["Treatment"].dropna().astype(str).unique())})
        resumo_tratamentos.to_excel(writer, sheet_name="Resumo_Tratamentos", index=False)
        
    logging.info(f"Etapa 1 Concluída. DataFrame Master gerado com {len(master_pub)} linhas.")

    # ---------------------------------------------------------
    # ETAPA 2: Reconstrução de Fórmulas Vivas com OpenPyXL
    # ---------------------------------------------------------
    pipeline.injetar_formulas_e_parametros(
        ARQUIVO_ENTRADA, 
        ARQUIVO_SAIDA, 
        ABAS_PROCESSAMENTO, 
        origem, 
        master_pub, 
        COLUNAS_COM_FORMULA
    )
    
    logging.info("=== PROCESSO FINALIZADO COM SUCESSO ===")
    print(f"\n[Sucesso] O arquivo profissional foi gerado em: {ARQUIVO_SAIDA}\n")

if __name__ == "__main__":
    main()