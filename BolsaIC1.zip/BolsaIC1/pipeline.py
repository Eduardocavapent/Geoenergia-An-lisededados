import os
import re
import logging
import pandas as pd
import openpyxl
from config import MAPEAMENTO_COLUNAS, LINHA_CABECALHO_EXCEL, NOMES_PARAMETROS_EXCEL

# Configuração de Logs profissional
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def mapear_nozzle_type(aba: str) -> str:
    """Retorna o tipo de bocal baseado no nome da aba."""
    mapeamento = {
        "Data-3mm": "3 mm",
        "Data-2mm": "2 mm",
        "Data-2mm-gas": "2 mm + gas"
    }
    return mapeamento.get(aba, "Desconhecido")

def extrair_oil_e_treatment(df: pd.DataFrame) -> pd.DataFrame:
    """
    Processa a coluna 'Experimento' para extrair de forma robusta
    as variáveis 'Oil_ID' e 'Treatment'.
    """
    oil_ids = []
    tratamentos = []
    ultimo_oleo = None

    for item in df["Experimento"]:
        texto = str(item).strip()
        if "-" in texto:
            partes = texto.split("-", 1)
            prefixo = partes[0].strip()
            sufixo = partes[1].strip()
            if prefixo.isdigit():
                ultimo_oleo = int(prefixo)
                oil_ids.append(ultimo_oleo)
                tratamentos.append(sufixo)
            else:
                oil_ids.append(ultimo_oleo)
                tratamentos.append(texto)
        else:
            if texto.isdigit():
                ultimo_oleo = int(texto)
                oil_ids.append(ultimo_oleo)
                tratamentos.append("Untreated")
            else:
                oil_ids.append(ultimo_oleo)
                tratamentos.append(texto)

    df["Oil_ID"] = oil_ids
    df["Treatment"] = tratamentos
    return df

def processar_etapa_dados(arquivo_excel: str, abas: list) -> tuple:
    """
    Executa a ETAPA 1: Leitura, filtragem estatística e estruturação dos dados brutos.
    """
    dados_finais = []
    
    for aba in abas:
        logging.info(f"Processando dados numéricos da aba: {aba}")
        # header=10 corresponde à linha 11 do Excel
        df_original = pd.read_excel(arquivo_excel, sheet_name=aba, header=LINHA_CABECALHO_EXCEL - 1)
        
        dados_aba = pd.DataFrame()
        dados_aba["Experimento"] = df_original.iloc[:, 1]
        
        # Metadados de rastreio de origem
        dados_aba["__aba"] = aba
        dados_aba["__linha_excel"] = df_original.index + (LINHA_CABECALHO_EXCEL + 1)
        
        # Mapeamento dinâmico baseado no dicionário de configurações
        for idx, (col_letra, col_nome) in enumerate(MAPEAMENTO_COLUNAS.items()):
            # iloc[:, 2] em diante correlaciona com as colunas C, D, E...
            dados_aba[col_nome] = df_original.iloc[:, idx + 2]
            
        dados_aba["Nozzle_Type"] = mapear_nozzle_type(aba)
        
        # Limpeza e conversão de dados críticos
        dados_aba["Pred_d50_mm"] = pd.to_numeric(dados_aba["Pred_d50_mm"], errors="coerce")
        dados_aba["Meas_d50_mm"] = pd.to_numeric(dados_aba["Meas_d50_mm"], errors="coerce")
        dados_aba = dados_aba.dropna(subset=["Pred_d50_mm", "Meas_d50_mm"])
        dados_aba = dados_aba[(dados_aba["Pred_d50_mm"] > 0) & (dados_aba["Meas_d50_mm"] > 0)]
        
        dados_aba["Experimento"] = dados_aba["Experimento"].astype(str).str.strip()
        dados_aba = dados_aba[(dados_aba["Experimento"] != "") & (dados_aba["Experimento"] != "nan")]
        dados_aba = dados_aba[~dados_aba["Experimento"].str.contains("Amostra|Experiment|Unit|gotas|mm|l/min", case=False)]
        
        dados_aba = extrair_oil_e_treatment(dados_aba)
        dados_finais.append(dados_aba)

    # Consolidação do Master Dataset
    master = pd.concat(dados_finais, ignore_index=True)
    master["Ordem_SINTEF"] = range(len(master))
    
    # Reordenar colunas profissionalmente
    colunas_numericas = list(MAPEAMENTO_COLUNAS.values())
    ordem_colunas = ["Ordem_SINTEF", "Nozzle_Type", "Oil_ID", "Treatment"] + colunas_numericas + ["__aba", "__linha_excel"]
    master = master[ordem_colunas]
    
    for col in colunas_numericas:
        master[col] = pd.to_numeric(master[col], errors="coerce")
        
    master = master.dropna(subset=["Oil_ID"])
    master["Oil_ID"] = master["Oil_ID"].astype(int)
    master = master.sort_values(by=["Ordem_SINTEF"]).reset_index(drop=True)
    master = master.drop(columns=["Ordem_SINTEF"])
    
    origem = master[["__aba", "__linha_excel"]].copy()
    master_pub = master.drop(columns=["__aba", "__linha_excel"])
    
    return master_pub, origem

def traduzir_formula(formula: str, aba_origem: str, mapa_linha: dict, nome_para_col_master: dict, wb_cache_por_aba: dict) -> str:
    """
    Mecanismo Regex para tradução de referências de células originais para a aba Master.
    """
    re_cell = re.compile(r'(\$?)([A-Z]{1,2})(\$?)(\d+)')
    
    def repl(m):
        cifrao1, col, cifrao2, lin = m.group(1), m.group(2), m.group(3), int(m.group(4))
        if col not in MAPEAMENTO_COLUNAS:
            return m.group(0)
            
        chave = (aba_origem, lin)
        if chave in mapa_linha:
            nome_col = MAPEAMENTO_COLUNAS[col]
            col_master = nome_para_col_master.get(nome_col)
            linha_master = mapa_linha[chave]
            if col_master:
                return f"{cifrao1}{col_master}{cifrao2}{linha_master}"
                
        # Fallback para linhas filtradas
        ws_cache = wb_cache_por_aba[aba_origem]
        valor = ws_cache[f"{col}{lin}"].value
        return "0" if valor is None else str(valor)

    return re_cell.sub(repl, formula)

def injetar_formulas_e_parametros(arquivo_entrada: str, arquivo_saida: str, abas: list, origem: pd.DataFrame, master_pub: pd.DataFrame, colunas_com_formula: list):
    """
    Executa a ETAPA 2: Tradução de fórmulas via OpenPyXL e portabilidade de Named Ranges.
    """
    logging.info("Iniciando injeção de fórmulas vivas e parâmetros...")
    
    nome_para_col_master = {nome: openpyxl.utils.get_column_letter(i + 1) for i, nome in enumerate(master_pub.columns)}
    
    mapa_linha = {}
    for i, row in origem.iterrows():
        mapa_linha[(row["__aba"], int(row["__linha_excel"]))] = i + 2

    wb_origem = openpyxl.load_workbook(arquivo_entrada, data_only=False)
    wb_saida = openpyxl.load_workbook(arquivo_saida)
    ws_master = wb_saida["Master"]
    
    wb_cache = openpyxl.load_workbook(arquivo_entrada, data_only=True)
    wb_cache_por_aba = {aba: wb_cache[aba] for aba in abas}
    
    celulas_escritas = 0
    celulas_vazias = 0
    
    for (aba, linha_excel), linha_master in mapa_linha.items():
        ws_o = wb_origem[aba]
        for col in colunas_com_formula:
            cel_o = ws_o[f"{col}{linha_excel}"]
            nome_col = MAPEAMENTO_COLUNAS[col]
            col_master = nome_para_col_master[nome_col]
            destino = ws_master[f"{col_master}{linha_master}"]
            
            if cel_o.value is None:
                celulas_vazias += 1
                continue
                
            if isinstance(cel_o.value, str) and cel_o.value.startswith("="):
                destino.value = traduzir_formula(cel_o.value, aba, mapa_linha, nome_para_col_master, wb_cache_por_aba)
            else:
                destino.value = cel_o.value
            celulas_escritas += 1

    # Copiar aba de Parâmetros Globais
    if "Parameters" in wb_origem.sheetnames and "Parameters" not in wb_saida.sheetnames:
        src = wb_origem["Parameters"]
        dst = wb_saida.create_sheet("Parameters")
        for row in src.iter_rows():
            for cell in row:
                if cell.value is not None:
                    dst[cell.coordinate] = cell.value

    # Copiar os Named Ranges cruciais para a engenharia de reservatórios
    for nome in NOMES_PARAMETROS_EXCEL:
        if nome in wb_origem.defined_names and nome not in wb_saida.defined_names:
            dn = wb_origem.defined_names[nome]
            if "Parameters" in dn.attr_text:
                novo = openpyxl.workbook.defined_name.DefinedName(nome, attr_text=dn.attr_text)
                wb_saida.defined_names[nome] = novo

    wb_saida.save(arquivo_saida)
    logging.info(f"Fórmulas aplicadas com sucesso! Escritas: {celulas_escritas} | Vazias: {celulas_vazias}")